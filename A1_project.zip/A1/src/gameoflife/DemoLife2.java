package gameoflife;

import java.util.Arrays;

public class DemoLife2 {

	

}
