package gameoflife;

public class Life2 {

	
	/**
	 * Returns true if the specified cell is alive.
	 * 
	 * @param cells a two-dimensional array
	 * @param row a row index
	 * @param col a column index
	 * @return true if the specified cell is alive
	 * @throws IllegalArgumentException if row or col is not a valid index for
	 *                                   cells
	 */
	public static boolean isAlive(boolean[][] cells, int row, int col) {
		if (!Life2.isValid(cells, row, col)) {
			throw new IllegalArgumentException();
		}
		return cells[row][col];
	}
	
	

}
