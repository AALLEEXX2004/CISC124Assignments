package gameoflife;


public class Life2 {

	
	/**
	 * Returns true if the specified cell is alive.
	 * 
	 * @param cells a two-dimensional boolean
	 * @param row a row index
	 * @param col a column index
	 * @return true if the specified cell is alive
	 * @throws IllegalArgumentException if row or col is not a valid index for
	 *                                   cells
	 */
	public static int numRows(boolean[][] cells) {
		return cells[0].length;
	}
	
	
	public static int numCols(boolean[][] cells) {
		
		if(numRows(cells)>0) {
			return cells[0].length;
		}else {
			return 0;
		}
	}
	
	
	public static boolean isValid(boolean[][] cells,int row,int col) {
		if(row<0||row>=numRows(cells)) {
			return false;
		}else if(col <0||col>= numCols(cells)) {
			return false;
		}else {
			return true;
		}
		
	}
	
	
	public static boolean[][] clone(boolean[][] cells){
		int rows,cols;
		boolean[][] copy;
		
		rows = numRows(cells);
		cols = numCols(cells);
		
		for(int i=0;i<rows;i++) {
			row = 
		}
		return copy;
	}
	public static boolean isAlive(boolean[][] cells, int row, int col) {
		if (!Life2.isValid(cells, row, col)) {
			throw new IllegalArgumentException();
		}
		return cells[row][col];
	}
	
	

}
